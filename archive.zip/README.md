# ANTIfries

## Anti-fries is a non-governmental public opinion organization.

~~The parties involved in this project, the relevant groups involved, and the channel agree by default.~~

#### 与本项目相关的群组
    
🍟整点薯条 - 群组([@GetSomeFries](https://t.me/GetSomeFries))**[攻击对象]**  

#### 与本项目相关的频道

🍟整点薯条([@GetSomeFriesChannel](https://t.me/GetSomeFriesChannel))**[攻击对象]**

Anti-Fries 🍟薯条黑粉总会([@AntiFries](https://t.me/AntiFries))**[黑粉会]**

💩整点玛卡巴卡 - TG黑🍟总工会🪤([@FriesAuti](https://t.me/FriesAuti))**[黑粉会]**

### 相关表情包

[薯薯专属语录表情包(持续更新敬请关注)](https://t.me/addstickers/ANTIFRIESPLUS)  https://t.me/addstickers/ANTIFRIESPLUS

不完全的表情包源文件->[ANTIFRIESPLUS](https://github.com/for-the-ionia/ANTIfries/tree/main/Incomplete%20emoji)

##### 关于我们

telegram黑薯条总工会,Anti-Fries黑粉总会成立于2022年7月，旨在构建**友好，文明的交流环境**，总部设立在 461 Clementi Road Singapore 599491, SG，和维多利亚街81号。

##### 加入我们--点击即可
Anti-Fries 🍟薯条黑粉总会([@AntiFries](https://t.me/AntiFries))**[黑粉会]**

整点玛卡巴卡💩 - TG黑🍟总工会👊([@FriesAuti](https://t.me/FriesAuti))**[黑粉会]**

### 鸣谢
**感谢 [@VirgilClyne](https://github.com/VirgilClyne) 配合 这是专门黑他的**
